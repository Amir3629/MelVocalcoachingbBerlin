<Link
  href={link.href}
  className="text-white hover:text-white/80 transition-colors duration-300"
>
  {link.label}
</Link> 